# Implementation and verification notes

## Manuscript mapping

| Manuscript | Code | Design |
|---|---|---|
| 4.1 | `data.py` | Four harmonized clinical values and four observed flags; fit numeric statistics only on training patients |
| 4.2 | `model.py` | CNN 3x3 64→128→256 with pooling, GAP→128; clinical Dense(8→64) |
| 4.3 | `model.py` | Dense(128→32), Dense(64→32), shared 32-vector scorer, softmax weights, 192→64, 64→1 |
| 4.4 | `training.py` | AdamW; patience 10; validation-only temperature fit, logit/T |
| 4.5–4.6 | `data.py`,`cli.py` | Fixed patient-level locked test; five seed training runs; development-only 5-fold CV |
| 5.1 | `model.py`,`cli.py` | Two unimodal, eight fusion comparators, proposed model (11 total) |
| 5.2–5.3 | `metrics.py`,`statistics.py` | ROC-AUC, F1, calibration, AUC paired tests with Holm |
| 5.4 | `analyses.py`,`explain.py` | Modality removal, missingness, risk–coverage, decision curve, Grad-CAM |

## Parameter count

The proposed classifier's count, excluding any unused baseline layers, is:

- Conv(3→64): 1,792
- Conv(64→128): 73,856
- Conv(128→256): 295,168
- Dense(256→128): 32,896
- Dense(8→64): 576
- Attention: Dense(128→32) 4,128 + Dense(64→32) 2,080 + shared scorer 32 = **6,240**
- Dense(192→64): 12,352
- Dense(64→1): 65
- Sum: **422,945** trainable parameters

`tests/test_model_tf.py` verifies the exact count.

## Unresolved differences from the manuscript

1. **Dataset preparation**: The Word file doesn't supply the original preprocessed image manifests, patient IDs, augmentation degrees, DICOM windowing, or clinical preprocessing code. This repository accepts explicit manifest paths rather than attempting to recreate authors' cohort lists from aggregate totals.
2. **Image standardization**: Illustrative fixed constants 0.5 and 0.25 are used after per-image min–max scaling. These are implementation assumptions and must be checked against original run records.
3. **Small rotation**: `rotation_factor=0.03` in Keras represents approximately ±10.8°. The manuscript says only "small rotations"; confirm or change.
4. **Clinical density mapping**: MIAS F/G/D and CBIS BI-RADS values are mapped to a numerical four-field representation; exact original category encoding is not supplied in the manuscript. Check any mismatch before re-running.
5. **Baselines**: TFN, LMF, GMU, FiLM, DAFT and cross-attention variants are runnable implementations of the described operator families, but unreported implementation minutiae (normalization order, projections, optimizer nuances) cannot be assumed to reproduce the author's exact baselines. The strict late-fusion protocol independently trains unimodal CNN and MLP then averages probabilities.
6. **Validation schedule**: The same validation portion is used for stopping and temperature calibration, as described, though calibration could be improved by separate selection/calibration splits in a revised study.
7. **Statistical evidence**: Five seeds on a fixed test set produce dependent measurements; per-seed paired t-tests follow the manuscript but should not be mistaken for independent-patient inference. Bootstrap resampling is grouped by patient.
8. **Cross-cohort inference**: Requires strict access authorization to source-cohort checkpoints and target-cohort records. Do not transfer training data or temperatures across cohorts unless the experiment is specifically cross-cohort without recalibration.
9. **MIAS**: Source study uses only 115 abnormal cases (63 benign, 52 malignant), omitting normal background images. Patient-level split needs reliable patient IDs. The small 18-case test sample has wide uncertainty.
10. **No published output included**: The paper's AUCs 0.947, 0.887 and 0.958 are not generated, hardcoded or asserted by this code. Running on eligible data produces new output requiring verification.

## Clinical and research safety

No decisions should be made about patients with these scripts. CBIS-DDSM and MIAS access are subject to source terms; private mammograms and clinical data must remain under institutional governance. Do not put private identifiers, imaging records, unconsented data, or private weights in Git.
