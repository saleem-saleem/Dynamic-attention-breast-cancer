# Reproducibility protocol and reporting

## Cohorts (as stated in the supplied manuscript; not provided in this repository)

| Cohort | Cases | Benign | Malignant | Paper training/validation/test |
|---|---:|---:|---:|---|
| CBIS-DDSM | 3,100 | 1,650 | 1,450 | 2,170 / 465 / 465 |
| mini-MIAS abnormal subset | 115 | 63 | 52 | 80 / 17 / 18 |
| Private cohort | 1,200 | 620 | 580 | 840 / 180 / 180 |

The manuscript gives these image-level totals, but the source manifests and patient identifiers are not included. Consequently patient-level splitting can produce different image totals when one patient has multiple views. Never force a split at image level to obtain matching totals.

## Output table provenance

- `protocol_A_metrics.csv`: one row per model x training seed, recomputed from predictions, with actual confusion counts.
- `protocol_A_predictions.csv`: per-image calibrated predictions and modality weights. The same **patient-level** test split is shared across all methods and seeds.
- `protocol_B_metrics.csv`: five-fold development-only results; never pool with the locked test set.
- `summary.csv`: mean and SD across actual completed runs, no invented values.
- `paired_statistics.csv`: per-seed paired AUC comparisons, t-statistics, Holm-adjusted p values.
- `outputs/figures/*.png`: ROC, confusion matrices, reliability diagrams derived from saved prediction CSVs.
- `posthoc/*.csv`: decision-curve and risk-coverage raw values; single-seed DeLong where patient independence holds.

## Checklist before manuscript-specific results may be claimed

1. Reconstruct the **exact CBIS image inclusion list** and original patient IDs.
2. Check MIAS 115-case abnormal-only inclusion, ground-truth labels, and patient grouping.
3. Secure authorized access to private cohort without uploading identifiers to GitHub.
4. Resolve unspecified preprocessing constants and exact augmentation angles using original experiment logs; source defaults in this repository are not confirmed historical facts.
5. Verify image orientation, DICOM windowing, BI-RADS ordinal encoding, menopausal status mapping, preprocessing statistics, and calibration temperature.
6. Train all baselines with the declared common encoders, patient groups and training budget.
7. Log every random seed and checkpoint. Then compute the figures and tables from the saved outputs.
8. Report uncertainty for MIAS 18-case test set; avoid claims of significance from overlapping confidence intervals alone.
9. Do not compare demonstration graphics and synthetic examples with empirical metrics.

## Known run-time limitation of this release validation

Source code, CSV data utilities, statistics, plotting and synthetic fixture tests were validated in the authoring environment. This environment has Python 3.13 but no TensorFlow, whereas TensorFlow 2.16.1 is targeted on Python 3.11; therefore the neural-network forward pass and full training smoke test were **not** executed here. The GitHub Actions workflow installs TensorFlow in Python 3.11 and executes the TensorFlow-dependent unit tests. Do not report neural-network tests as passed before that workflow succeeds.
