# Contributing

Please propose changes with a short description, issue or methodology reference, unit test and any differences from the manuscript. Do not submit patient records, private mammograms, identifiable outputs, or manuscript figure reproductions made from simulated data without identifying them as synthetic. Preserve patient-level data isolation and validate accuracy/F1/AUC from predictions rather than fabricated summary scores.
