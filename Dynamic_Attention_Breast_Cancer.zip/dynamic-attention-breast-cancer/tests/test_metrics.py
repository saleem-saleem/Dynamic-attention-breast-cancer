import numpy as np
import pandas as pd
from breastfusion.metrics import evaluate_predictions,risk_coverage,decision_curve
from breastfusion.statistics import holm,paired_auc_test,patient_auc_bootstrap

def test_metrics_are_from_same_confusion_matrix():
    y=np.array([0,0,0,0,1,1,1,1]);p=np.array([.05,.15,.70,.25,.3,.8,.9,.75])
    m=evaluate_predictions(y,p)
    assert (m['tn'],m['fp'],m['fn'],m['tp'])==(3,1,1,3)
    assert m['accuracy']==.75
    assert m['precision']==m['recall']==m['f1']==.75
    assert abs(m['mcc']-.5)<1e-10
    assert all(0<=m[k]<=1 for k in ['auc','pr_auc','ece','brier'])

def test_holm_order():
    p=holm([.01,.04,.03])
    assert np.allclose(p,[.03,.06,.06])

def test_ttest_symmetric():
    a=[.9,.91,.93,.95,.94];b=[.88,.89,.9,.93,.91]
    x=paired_auc_test(a,b)
    y=paired_auc_test(b,a)
    assert np.isclose(x['t'],-y['t'])
    assert x['p']==y['p']

def test_bootstrap_grouped_by_patient():
    frame=pd.DataFrame({'patient_id':[f'p{i}' for i in range(20)],
         'label':[i%2 for i in range(20)],
         'probability':[.2 if i%2==0 else .8 for i in range(20)]})
    lo,hi=patient_auc_bootstrap(frame,50)
    assert lo==hi==1

def test_decision_curve_and_selective_prediction():
    y=np.array([0,0,1,1]); p=np.array([.1,.8,.6,.9])
    assert len(decision_curve(y,p))>0
    assert risk_coverage(y,p,step=.25)[-1]['coverage']==1
