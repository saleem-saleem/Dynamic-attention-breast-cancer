import pytest

tf=pytest.importorskip('tensorflow')
from breastfusion.model import build_model
from breastfusion.training import fit_temperature
import numpy as np

def test_exact_manuscript_parameter_count():
    model=build_model('proposed',image_size=64)
    assert model.count_params()==422945
    out=model((tf.zeros([3,64,64,3]),tf.zeros([3,8])))
    assert out['logits'].shape==(3,)
    weights=out['weights'].numpy()
    np.testing.assert_allclose(weights.sum(axis=1),1,atol=1e-6)

def test_all_baseline_operators():
    for method in ['image_only','clinical_only','early','tfn','lmf','gmu','film','daft','cross_attention','no_regularization']:
        model=build_model(method,image_size=32)
        out=model((tf.zeros([2,32,32,3]),tf.zeros([2,8])))
        assert out['logits'].shape==(2,)

def test_temperature_positive():
    temp=fit_temperature([-2,-1,1,2],[0,0,1,1])
    assert temp>0
