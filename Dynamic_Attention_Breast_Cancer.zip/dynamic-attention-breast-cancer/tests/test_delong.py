import numpy as np
from sklearn.metrics import roc_auc_score
from breastfusion.delong import correlated_delong

def test_delong_matches_sklearn_auc():
    y=np.array([0]*12+[1]*12)
    rng=np.random.default_rng(15)
    a=rng.uniform(size=len(y))+.5*y
    b=rng.uniform(size=len(y))+.2*y
    v=correlated_delong(y,a,b)
    assert abs(v['auc_a']-roc_auc_score(y,a))<1e-9
    assert abs(v['auc_b']-roc_auc_score(y,b))<1e-9
    assert -1<=v['difference']<=1
    assert v['p'] is None or 0<=v['p']<=1
