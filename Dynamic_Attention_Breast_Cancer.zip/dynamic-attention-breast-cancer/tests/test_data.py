import numpy as np
import pandas as pd
from breastfusion.data import make_splits,cv_splits,ClinicalPreprocessor,assert_no_overlap
from breastfusion.demo import make_demo

def dummy(n=100):
    return pd.DataFrame({'patient_id':[f'p{i:04d}' for i in range(n)],
       'cohort':['demo']*n,'image_path':['unused']*n,'label':[i%2 for i in range(n)],
       'age':[np.nan if i%10==0 else i/2 for i in range(n)],
       'breast_density':[i%4+1 for i in range(n)],
       'bmi':[np.nan]*n,'menopausal_status':[np.nan]*n})

def test_stratified_patient_splits():
    d=dummy(100);s=make_splits(d,2025,.15,.15)
    assert sum(len(x) for x in s.values())==100
    assert_no_overlap(s)
    assert len(s['test'])==15
    assert all(set(x.label)=={0,1} for x in s.values())

def test_cv_test_locked_out():
    d=dummy(100)
    outer=make_splits(d)
    dev=pd.concat([outer['train'],outer['val']]); locked=set(outer['test'].patient_id)
    folds=list(cv_splits(dev))
    assert len(folds)==5
    for idx,split in folds:
        assert not set(pd.concat(list(split.values())).patient_id) & locked

def test_missingness_and_training_only_imputation():
    d=dummy(10)
    fitted=ClinicalPreprocessor().fit(d)
    x=fitted.transform(d)
    assert x.shape==(10,8)
    assert np.all(x[:,2]==0) and np.all(x[:,6]==0)
    assert x[0,4]==0 and x[1,4]==1
    assert np.all(np.isfinite(x))

def test_demo_written(tmp_path):
    manifest=make_demo(tmp_path,20)
    frame=pd.read_csv(manifest)
    assert frame.label.sum()==10
    assert all((tmp_path/path).exists() for path in frame.image_path)
