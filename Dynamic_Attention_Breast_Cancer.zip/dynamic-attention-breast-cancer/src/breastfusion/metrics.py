"""Metrics recomputed from prediction files, never hand-entered result values."""
import numpy as np
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
      roc_auc_score, average_precision_score, confusion_matrix, matthews_corrcoef,
      balanced_accuracy_score, log_loss, brier_score_loss)

def _confidence_bins(y,p,bins=10,equal_mass=False):
    p=np.clip(np.asarray(p,dtype=float),1e-7,1-1e-7)
    y=np.asarray(y,dtype=int)
    conf=np.maximum(p,1-p)
    correct=((p>=.5)==y).astype(float)
    if equal_mass:
        order=np.argsort(conf)
        groups=np.array_split(order,bins)
    else:
        edges=np.linspace(0,1,bins+1)
        groups=[np.where((conf>=edges[j]) & (conf<edges[j+1] if j<bins-1 else conf<=edges[j+1]))[0]
                for j in range(bins)]
    return [(len(ix), float(np.mean(conf[ix])),float(np.mean(correct[ix]))) for ix in groups if len(ix)]

def calibration_metrics(y,p,bins=10,equal_mass=False):
    groups=_confidence_bins(y,p,bins,equal_mass)
    n=len(y)
    gaps=np.array([abs(a-b) for _,a,b in groups]); sizes=np.array([nn for nn,_,_ in groups])
    return {'ece':float(np.sum(sizes*gaps)/n),'mce':float(np.max(gaps)),
            'nll':float(log_loss(y,np.clip(p,1e-7,1-1e-7),labels=[0,1])),
            'brier':float(brier_score_loss(y,p))}

def evaluate_predictions(y,p,threshold=.5,bins=10,equal_mass=False):
    y=np.asarray(y,dtype=int); p=np.asarray(p,dtype=float)
    if len(y)!=len(p) or len(y)==0: raise ValueError('y/p length mismatch')
    pred=(p>=threshold).astype(int)
    tn,fp,fn,tp=confusion_matrix(y,pred,labels=[0,1]).ravel().astype(int)
    out=dict(n=len(y), tn=int(tn),fp=int(fp),fn=int(fn),tp=int(tp),
             accuracy=float(accuracy_score(y,pred)), precision=float(precision_score(y,pred,zero_division=0)),
             recall=float(recall_score(y,pred,zero_division=0)),
             specificity=float(tn/max(tn+fp,1)),
             f1=float(f1_score(y,pred,zero_division=0)),
             balanced_accuracy=float(balanced_accuracy_score(y,pred)),
             mcc=float(matthews_corrcoef(y,pred)),
             auc=float(roc_auc_score(y,p)) if len(np.unique(y))==2 else None,
             pr_auc=float(average_precision_score(y,p)) if len(np.unique(y))==2 else None)
    out.update(calibration_metrics(y,p,bins,equal_mass))
    assert tp+tn+fp+fn==len(y)
    return out

def risk_coverage(y,p,step=.05):
    y=np.asarray(y); p=np.asarray(p)
    conf=np.maximum(p,1-p); order=np.argsort(-conf)
    result=[]
    for coverage in np.arange(step,1+1e-8,step):
        count=max(1,int(np.ceil(len(y)*coverage)))
        idx=order[:count]
        error=float(np.mean((p[idx]>=.5)!=y[idx]))
        result.append({'coverage':float(coverage),'risk':error,'kept':count})
    return result

def decision_curve(y,p,thresholds=None):
    if thresholds is None: thresholds=np.linspace(.02,.98,49)
    y=np.asarray(y);p=np.asarray(p); n=len(y)
    out=[]
    for t in thresholds:
        pred=p>=t
        tp=np.sum(pred & (y==1)); fp=np.sum(pred & (y==0))
        nb=tp/n-fp/n*t/(1-t)
        prevalence=np.mean(y)
        out.append({'threshold':float(t),'net_benefit':float(nb),
          'treat_all':float(prevalence-(1-prevalence)*t/(1-t)),'treat_none':0.0})
    return out
