"""Patient-disjoint split, clinical preprocessing, and streaming image decoding.
The manifest contains PATHS, not patient records; publish only de-identified examples.
"""
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold

FIELDS = ['age','breast_density','bmi','menopausal_status']
COHORTS = {'cbis','mias','private','demo'}

def read_manifest(path, cohort=None):
    path=Path(path)
    df=pd.read_csv(path, keep_default_na=True)
    for col in ('cohort','patient_id','image_path','label'):
        if col not in df: raise ValueError(f'Missing required column {col}')
    for col in FIELDS + ['lesion_mask_path','morphology']:
        if col not in df: df[col]=np.nan
    if cohort:
        df=df.loc[df.cohort.astype(str).str.lower().eq(cohort.lower())].copy()
    if len(df)==0: raise ValueError('Empty cohort')
    df['label']=pd.to_numeric(df.label,errors='raise').astype(int)
    if not set(df.label).issubset({0,1}): raise ValueError('Labels must be 0 benign / 1 malignant')
    # Cohort-scoped identifier; a patient may not have contradictory labels.
    if (df.groupby('patient_id').label.nunique()>1).any():
        raise ValueError('Conflicting patient labels (patient-level stratification not possible)')
    df['image_path']=df.image_path.map(lambda p: str((path.parent/str(p)).resolve()) if not Path(str(p)).is_absolute() else str(p))
    df['lesion_mask_path']=df.lesion_mask_path.map(lambda p: str((path.parent/str(p)).resolve()) if pd.notna(p) and not Path(str(p)).is_absolute() else p)
    return df.reset_index(drop=True)

def _patient_table(df):
    return df.groupby('patient_id',as_index=False).label.first()

def _split_patients(patients, frac, seed):
    if patients.label.nunique()!=2: raise ValueError('Need both classes to stratify')
    aa, bb = train_test_split(patients, test_size=frac, stratify=patients.label, random_state=seed)
    return aa, bb

def make_splits(df, seed=2025, test_frac=0.15, val_frac=0.15):
    """Test first; validation is val_frac / (1-test_frac) of development patients.
    Image counts can differ from exact 70/15/15 when patient has multiple images.
    """
    patients=_patient_table(df)
    development, test=_split_patients(patients,test_frac,seed)
    train, val = _split_patients(development,val_frac/(1-test_frac),seed+1)
    parts={k:df[df.patient_id.isin(pt.patient_id)].reset_index(drop=True)
           for k,pt in [('train',train),('val',val),('test',test)]}
    assert_no_overlap(parts)
    return parts

def cv_splits(df, seed=2026, n_splits=5, earlystop_frac=0.15):
    patients=_patient_table(df)
    cv=StratifiedKFold(n_splits=n_splits,shuffle=True,random_state=seed)
    for fold,(ti,vi) in enumerate(cv.split(patients.patient_id,patients.label),1):
        tr_pat, va_pat= _split_patients(patients.iloc[ti],earlystop_frac,seed+fold)
        va_fold_pat=patients.iloc[vi]
        pieces={k:df[df.patient_id.isin(p.patient_id)].reset_index(drop=True)
                for k,p in [('train',tr_pat),('val',va_pat),('test',va_fold_pat)]}
        assert_no_overlap(pieces)
        yield fold,pieces

def assert_no_overlap(parts):
    names=list(parts)
    for i,a in enumerate(names):
        for b in names[i+1:]:
            overlap=set(parts[a].patient_id).intersection(parts[b].patient_id)
            if overlap: raise ValueError(f'Patient leakage {a}/{b}: {list(overlap)[:4]}')

class ClinicalPreprocessor:
    """Uses train-only median, min/max. 4 values + 4 observed indicators.
    Cohort-absent fields are always zero and missingness indicators are zero.
    """
    def __init__(self):
        self.params={}
        self.available=[]
    @staticmethod
    def _numeric(series, field):
        if field=='breast_density':
            map_={'a':1,'b':2,'c':3,'d':3,'f':1,'g':2,'1':1,'2':2,'3':3,'4':4}
            ss=series.astype('string').str.strip().str.lower()
            mapped=ss.map(map_)
            return pd.to_numeric(mapped.where(mapped.notna(),ss),errors='coerce')
        if field=='menopausal_status':
            mp={'pre':0,'premenopausal':0,'post':1,'postmenopausal':1,'0':0,'1':1}
            ss=series.astype('string').str.strip().str.lower()
            mapped=ss.map(mp)
            return pd.to_numeric(mapped.where(mapped.notna(),ss),errors='coerce')
        return pd.to_numeric(series,errors='coerce')
    def fit(self, training):
        if len(training)==0: raise ValueError('Cannot fit without samples')
        self.params={}; self.available=[]
        for field in FIELDS:
            s=self._numeric(training[field],field)
            observed=s.dropna()
            if len(observed)==0:
                self.params[field]={'available':False,'median':0.,'min':0.,'max':1.}
            else:
                self.available.append(field)
                self.params[field]={'available':True, 'median':float(observed.median()),
                    'min':float(observed.min()), 'max':float(observed.max())}
        return self
    def transform(self, df):
        if not self.params: raise RuntimeError('Fit on training rows first')
        values=[]; flags=[]
        for field in FIELDS:
            s=self._numeric(df[field],field)
            p=self.params[field]
            obs=(s.notna() & p['available']).to_numpy(dtype=np.float32)
            if p['available']:
                filled=s.fillna(p['median']).to_numpy(dtype=np.float32)
                span=p['max']-p['min']
                scaled=np.clip((filled-p['min'])/span,0,1) if span>1e-12 else np.zeros_like(filled)
            else: scaled=np.zeros(len(df),dtype=np.float32)
            values.append(scaled);flags.append(obs)
        return np.stack(values+flags,axis=1).astype(np.float32)
    def to_dict(self): return {'fields':FIELDS, 'parameters':self.params}

def load_image_np(path, size=224):
    """Loader for PNG/JPG/PGM/TIFF and optional DICOM. Per-image [0,1] contrast scaling.
    The manuscript's exact mammography windowing was not specified; verify original preprocessing.
    """
    from PIL import Image
    path=str(path)
    if path.lower().endswith(('.dcm','.dicom')):
        try:
            import pydicom
            from pydicom.pixel_data_handlers.util import apply_voi_lut
        except ImportError as exc:
            raise ImportError('Install pydicom to load DICOM files') from exc
        ds=pydicom.dcmread(path)
        arr=np.asarray(apply_voi_lut(ds.pixel_array,ds),dtype=np.float32)
        if ds.get('PhotometricInterpretation','')=='MONOCHROME1': arr=arr.max()-arr
    else:
        with Image.open(path) as img: arr=np.asarray(img.convert('L'),dtype=np.float32)
    low,high=float(np.min(arr)),float(np.max(arr))
    arr=(arr-low)/(high-low) if high>low else np.zeros_like(arr)
    im=Image.fromarray((arr*255).astype(np.uint8),'L').resize((size,size),Image.Resampling.BILINEAR)
    grey=np.asarray(im,dtype=np.float32)/255.0
    rgb=np.repeat(grey[...,None],3,axis=2)
    return (rgb-.5)/.25  # fixed standardization: mean 0.5, SD 0.25; verify original constants

def make_tf_dataset(df, xclin, size=224, batch=32, training=False, seed=11,
                    rotation=0.03, flip=True):
    import tensorflow as tf
    paths=df.image_path.astype(str).to_numpy()
    labels=df.label.to_numpy(dtype=np.float32)
    ds=tf.data.Dataset.from_tensor_slices((paths, xclin.astype(np.float32),labels))
    def decode(path,x,label):
        def py_loader(pathbytes):
            p=pathbytes.numpy().decode('utf8')
            return load_image_np(p,size)
        image=tf.py_function(py_loader,[path],Tout=tf.float32)
        image.set_shape([size,size,3])
        return image,x,label
    ds=ds.map(decode,num_parallel_calls=tf.data.AUTOTUNE)
    if training:
        ds=ds.shuffle(min(max(len(df),1),4096),seed=seed,reshuffle_each_iteration=True)
        # Stateless tf.image ops are preferable for bit-identical reruns; this is seed-controlled stochastic augmentation.
        augment_layers=([tf.keras.layers.RandomFlip('horizontal')] if flip else [])
        if rotation>0: augment_layers.append(tf.keras.layers.RandomRotation(rotation))
        aug=tf.keras.Sequential(augment_layers,name='train_augmentation')
        ds=ds.batch(batch).map(lambda i,c,y:(aug(i,training=True),c,y),num_parallel_calls=tf.data.AUTOTUNE)
    else: ds=ds.batch(batch)
    return ds.prefetch(tf.data.AUTOTUNE)
