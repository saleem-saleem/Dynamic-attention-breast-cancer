"""Post-hoc reproducible analyses; only predictions and labels from actual runs are valid evidence."""
from pathlib import Path
import pandas as pd
import numpy as np
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from .statistics import paired_auc_test, holm
from .metrics import decision_curve,risk_coverage,evaluate_predictions

def paired_comparisons(metrics_path,out):
    df=pd.read_csv(metrics_path)
    key='seed' if 'seed' in df else 'fold'
    rows=[]
    for cohort,sub in df.groupby('cohort'):
        if 'proposed' not in set(sub.model): continue
        baseline_names=[x for x in sorted(set(sub.model)) if x!='proposed']
        testrows=[]
        for model in baseline_names:
            aligned=sub[sub.model.isin(['proposed',model])].pivot_table(index=key,columns='model',values='auc',aggfunc='mean').dropna()
            if len(aligned)<3: continue
            stat=paired_auc_test(aligned['proposed'].values,aligned[model].values,corrected_cv=(key=='fold'))
            testrows.append({'cohort':cohort,'comparison':f'proposed - {model}','protocol':'B' if key=='fold' else 'A',**stat})
        valid=[x for x in testrows if x['p'] is not None]
        adjusted=holm([x['p'] for x in valid]) if valid else []
        for row,adj in zip(valid,adjusted):row['p_holm']=adj
        rows.extend(testrows)
    Path(out).parent.mkdir(parents=True,exist_ok=True)
    pd.DataFrame(rows).to_csv(out,index=False)
    return rows

def modality_counterfactual(model,prep,df,cfg,temperature):
    """Re-run inference after dropping clinical inputs / replacing image with cohort mean.
    Returns probabilities, weights, absolute perturbation effects, and correlations.
    """
    from scipy.special import expit
    from .data import load_image_np
    X=np.stack([load_image_np(p,cfg['image_size']) for p in df.image_path],axis=0)
    C=prep.transform(df)
    import tensorflow as tf
    pred=lambda i,c:model((tf.convert_to_tensor(i),tf.convert_to_tensor(c)),training=False)
    original=pred(X,C)
    orig=expit(original['logits'].numpy()/temperature)
    weights=original['weights'].numpy()
    minus_clin=expit(pred(X,np.zeros_like(C))['logits'].numpy()/temperature)
    minus_img=expit(pred(np.broadcast_to(X.mean(axis=0),X.shape).copy(),C)['logits'].numpy()/temperature)
    loss_clin=np.abs(orig-minus_clin);loss_img=np.abs(orig-minus_img)
    return {'rho_clinical':float(spearmanr(weights[:,1],loss_clin).statistic),
            'rho_image':float(spearmanr(weights[:,0],loss_img).statistic),
            'table':pd.DataFrame({'patient_id':df.patient_id,'p_full':orig,'alpha':weights[:,0],
                                 'beta':weights[:,1],'delta_image':loss_img,'delta_clinical':loss_clin})}

def clinical_missingness(model,prep,df,cfg,temperature,fractions=(0,.25,.5,.75,1.0),seed=2025):
    """Randomly remove observed clinical fields after fitting; do not re-train model."""
    from scipy.special import expit
    from .data import load_image_np
    from sklearn.metrics import roc_auc_score
    import tensorflow as tf
    rng=np.random.default_rng(seed)
    X=np.stack([load_image_np(p,cfg['image_size']) for p in df.image_path])
    C=prep.transform(df);out=[]
    for frac in fractions:
        masked=C.copy()
        observed=np.argwhere(masked[:,4:]>0)
        take=rng.choice(len(observed),int(round(frac*len(observed))),replace=False)
        for row,col in observed[take]:masked[row,col]=0;masked[row,col+4]=0
        y=df.label.to_numpy()
        raw=model((tf.convert_to_tensor(X),tf.convert_to_tensor(masked)),training=False)
        p=expit(raw['logits'].numpy()/temperature)
        out.append({'missing_fraction':float(frac),'auc':roc_auc_score(y,p),
                    'median_alpha':float(np.median(raw['weights'].numpy()[:,0]))})
    return pd.DataFrame(out)

def threshold_outputs(pred_file,directory):
    """No threshold selection; test-time descriptive analysis only."""
    data=pd.read_csv(pred_file)
    out=Path(directory);out.mkdir(parents=True,exist_ok=True)
    all_dc=[];all_rc=[]
    for (cohort,model,seed),group in data.groupby(['cohort','model','seed']):
        if group.patient_id.duplicated().any():
            print('NOTICE: repeated patient records; decisions are at image-level.')
        dc=pd.DataFrame(decision_curve(group.label,group.probability))
        rc=pd.DataFrame(risk_coverage(group.label,group.probability))
        for d in (dc,rc):
            d['cohort']=cohort;d['model']=model;d['seed']=seed
        all_dc.append(dc);all_rc.append(rc)
    pd.concat(all_dc).to_csv(out/'decision_curve.csv',index=False)
    pd.concat(all_rc).to_csv(out/'risk_coverage.csv',index=False)

def subgroup_performance(predictions, metadata, group_col, min_cases=10):
    """Join non-sensitive analytical strata by patient ID; compute honest small-group counts.
    Must use real test predictions and held-out subgroup labels; do not use for tuning.
    """
    from .metrics import evaluate_predictions
    d=predictions.merge(metadata[['patient_id',group_col]],on='patient_id',validate='many_to_one')
    records=[]
    for subgroup,part in d.groupby(group_col,dropna=False):
        if len(part)<min_cases or part.label.nunique()<2:
            records.append({'group':str(subgroup),'n':len(part),'auc':np.nan,
                            'note':'too small or one class'})
        else:
            met=evaluate_predictions(part.label,part.probability)
            records.append({'group':str(subgroup),'n':len(part),'auc':met['auc'],
                            'f1':met['f1'],'accuracy':met['accuracy'],'note':''})
    return pd.DataFrame(records)
