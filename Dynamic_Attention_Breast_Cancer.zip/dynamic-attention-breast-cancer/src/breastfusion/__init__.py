"""Dynamic mammography/clinical fusion research implementation.
No clinical validation or manuscript result reproduction is implied by this package.
"""
__version__ = "0.1.0"
