"""Grad-CAM + localization checks. Attention weights are NOT clinical explanations."""
import numpy as np

def gradcam(model,image,clinical):
    """Return normalized heatmap for one sample, from Conv3 pooled feature map."""
    import tensorflow as tf
    image=tf.convert_to_tensor(image[None],dtype=tf.float32)
    clinical=tf.convert_to_tensor(clinical[None],dtype=tf.float32)
    with tf.GradientTape() as tape:
        out=model((image,clinical),training=False)
        fmap=out['feature_map']
        tape.watch(fmap)
        target=out['logits'][0]
    gradients=tape.gradient(target,fmap)
    if gradients is None: raise RuntimeError('Gradients unavailable for target feature map')
    weights=tf.reduce_mean(gradients,axis=(1,2),keepdims=True)
    heat=tf.nn.relu(tf.reduce_sum(weights*fmap,axis=-1))
    heat=heat/(tf.reduce_max(heat)+1e-7)
    return heat[0].numpy()

def pointing_game(heatmap,mask):
    """True if maximum activation hits expert binary mask. Use only real annotations."""
    from PIL import Image
    mask=np.asarray(mask,dtype=np.float32)
    if mask.ndim==3:mask=mask[:,:,0]
    mask=np.asarray(Image.fromarray(mask).resize((heatmap.shape[1],heatmap.shape[0]),Image.Resampling.NEAREST))
    return int(mask[np.unravel_index(np.argmax(heatmap),heatmap.shape)]>0)

def localization_iou(heatmap,mask,threshold=.5):
    """Threshold-relative Grad-CAM IoU; should not be claimed as lesion segmentation Dice."""
    from PIL import Image
    gt=np.asarray(Image.fromarray(np.asarray(mask,dtype=np.uint8)).resize(
        (heatmap.shape[1],heatmap.shape[0]),Image.Resampling.NEAREST))>0
    predicted=heatmap>=threshold
    union=np.logical_or(gt,predicted).sum()
    return float(np.logical_and(gt,predicted).sum()/union) if union else float('nan')
