"""Fast DeLong test for two correlated ROC-AUC estimates (binary independent cases).
Adaptation of the midrank-based estimator. For repeated images of a patient,
consider patient-level clustered resampling instead of interpreting this p-value.
"""
import numpy as np
from scipy.stats import norm

def midrank(x):
    x=np.asarray(x);order=np.argsort(x);sorted_x=x[order]
    ranks=np.empty(len(x),dtype=float)
    i=0
    while i<len(x):
        j=i
        while j+1<len(x) and sorted_x[j+1]==sorted_x[i]: j+=1
        ranks[i:j+1]=(i+j)/2+1
        i=j+1
    answer=np.empty(len(x),dtype=float);answer[order]=ranks
    return answer

def correlated_delong(y, score_a, score_b):
    y=np.asarray(y,dtype=int)
    if set(y)!={0,1}:raise ValueError('Need positive and negative labels')
    scores=np.vstack([score_a,score_b]).astype(float)
    idx=np.argsort(-y);m=int(y.sum());n=len(y)-m
    ss=scores[:,idx]
    tx=np.vstack([midrank(x[:m]) for x in ss])
    ty=np.vstack([midrank(x[m:]) for x in ss])
    tz=np.vstack([midrank(x) for x in ss])
    auc=tz[:,:m].sum(axis=1)/(m*n)-(m+1)/(2*n)
    if m<2 or n<2:raise ValueError('Need at least two examples per class')
    v01=(tz[:,:m]-tx)/n
    v10=1-(tz[:,m:]-ty)/m
    cov=np.cov(v01)/m + np.cov(v10)/n
    diff=float(auc[0]-auc[1]);variance=float(np.array([1,-1])@cov@np.array([1,-1]))
    if variance<=0:
        return {'auc_a':float(auc[0]),'auc_b':float(auc[1]),'difference':diff,'z':None,'p':None}
    z=diff/np.sqrt(variance)
    return {'auc_a':float(auc[0]),'auc_b':float(auc[1]),'difference':diff,'z':float(z),
            'p':float(2*norm.sf(abs(z)))}
