import json, random
from pathlib import Path
import numpy as np

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.keras.utils.set_random_seed(seed)
        try: tf.config.experimental.enable_op_determinism()
        except Exception: pass
    except ImportError: pass

def write_json(path, obj):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('w', encoding='utf8') as f:
        json.dump(obj, f, indent=2, default=lambda x: float(x) if isinstance(x, np.generic) else str(x))
