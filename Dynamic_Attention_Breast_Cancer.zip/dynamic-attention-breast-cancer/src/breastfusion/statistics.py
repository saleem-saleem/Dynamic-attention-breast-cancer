import numpy as np
from scipy import stats
from sklearn.metrics import roc_auc_score

def holm(pvalues):
    """Holm step-down multiplicity correction; adjusted values in original order."""
    p=np.asarray(pvalues,dtype=float)
    order=np.argsort(p); adjusted=np.empty(len(p))
    running=0.0; m=len(p)
    for i,idx in enumerate(order):
        running=max(running,(m-i)*p[idx]);adjusted[idx]=min(1.0,running)
    return adjusted.tolist()

def paired_auc_test(proposed, baseline, corrected_cv=False):
    """Protocol A: paired t over five seeds. B: corrected five-fold t (Nadeau-Bengio approximation).
    The test-set patients overlap across seeds, so seed-based p-values remain exploratory.
    """
    x=np.asarray(proposed,dtype=float); z=np.asarray(baseline,dtype=float)
    if len(x)!=len(z) or len(x)<3: raise ValueError('Need paired arrays with >=3 runs')
    d=x-z; mean=float(d.mean()); sd=float(d.std(ddof=1))
    if sd==0:
        return dict(mean_difference=mean,t=None,p=None,ci95=[mean,mean],dz=None)
    if corrected_cv:
        factor=np.sqrt(1/len(d)+1/(len(d)-1))
    else: factor=1/np.sqrt(len(d))
    tval=mean/(sd*factor)
    p=float(2*stats.t.sf(abs(tval),len(d)-1))
    q=stats.t.ppf(.975,len(d)-1)
    return {'mean_difference':mean,'t':float(tval),'p':p,
            'ci95':[float(mean-q*sd*factor),float(mean+q*sd*factor)],
            'dz':float(mean/sd)}

def patient_auc_bootstrap(df, n_boot=2000, seed=2025):
    """df columns patient_id, label, probability. Resample patients, not images."""
    rng=np.random.default_rng(seed)
    ids=df.patient_id.unique(); grouped={i:df[df.patient_id==i] for i in ids}
    aucs=[]
    for _ in range(n_boot):
        sampled=rng.choice(ids,size=len(ids),replace=True)
        yy=np.concatenate([grouped[i].label.to_numpy() for i in sampled])
        pp=np.concatenate([grouped[i].probability.to_numpy() for i in sampled])
        if len(set(yy))>1: aucs.append(roc_auc_score(yy,pp))
    return [float(x) for x in np.percentile(aucs,[2.5,97.5])]
