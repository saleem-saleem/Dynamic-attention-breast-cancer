"""Plot real run outputs, not hardcoded manuscript curves."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve,ConfusionMatrixDisplay,confusion_matrix

def save_plots(csv_path,out_dir):
    df=pd.read_csv(csv_path)
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    for (cohort,method),g in df.groupby(['cohort','model']):
        # Seed 11 plot: seed-level held-out set (avoid multiplying cases across seeds).
        if 'seed' in g: g=g[g.seed==g.seed.min()]
        y=g.label.to_numpy();p=g.probability.to_numpy()
        if len(set(y))<2:continue
        fpr,tpr,_=roc_curve(y,p)
        fig,ax=plt.subplots(figsize=(5.5,4.5));ax.plot(fpr,tpr,label=f'{method} (computed)');ax.plot([0,1],[0,1],'--',alpha=.5)
        ax.set(xlabel='False positive rate',ylabel='True positive rate',title=f'{cohort} | ROC | seed {g.seed.min()}')
        ax.legend();fig.tight_layout();fig.savefig(out/f'{cohort}_{method}_roc.png',dpi=250);plt.close(fig)
        cm=confusion_matrix(y,p>=.5,labels=[0,1]);fig,ax=plt.subplots(figsize=(5,4))
        ConfusionMatrixDisplay(cm,display_labels=['benign','malignant']).plot(ax=ax,cmap='Blues',colorbar=False)
        ax.set_title(f'{cohort} | {method}');fig.tight_layout();fig.savefig(out/f'{cohort}_{method}_confusion.png',dpi=250);plt.close(fig)
        fig,ax=plt.subplots(figsize=(5,4))
        confidence=np.maximum(p,1-p);correct=((p>=.5)==y).astype(float)
        bcount=5 if cohort=='mias' else 10; edges=np.linspace(.5,1,bcount+1)
        obs=[];pred=[]
        for j in range(bcount):
            sel=(confidence>=edges[j])&(confidence<(edges[j+1]) if j<bcount-1 else confidence<=edges[j+1])
            if sel.sum():obs.append(np.mean(correct[sel]));pred.append(np.mean(confidence[sel]))
        ax.plot([.5,1],[.5,1],'--',label='Ideal');ax.plot(pred,obs,'o-',label='Measured');ax.set(
            xlabel='Mean confidence',ylabel='Fraction correct',xlim=(.5,1),ylim=(.5,1),title=f'{cohort} | {method} | reliability')
        ax.legend();fig.tight_layout();fig.savefig(out/f'{cohort}_{method}_reliability.png',dpi=250);plt.close(fig)
    print(f'Saved figures in {out}')
