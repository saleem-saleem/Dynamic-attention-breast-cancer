from pathlib import Path
import yaml

DEFAULTS = dict(image_size=224, batch_size=32, max_epochs=75, patience=10,
                learning_rate=5e-4, weight_decay=1e-5, adam_epsilon=1e-7,
                dropout=0.4, attention_dim=32, threshold=0.5,
                split_seed=2025, cv_seed=2026, seeds=[11,22,33,44,55],
                test_fraction=0.15, validation_fraction=0.15,
                rotation_factor=0.03, augment_flip=True, bootstrap_repeats=2000)

def load_config(path):
    with open(path, encoding="utf-8") as f:
        custom = yaml.safe_load(f) or {}
    cfg = {**DEFAULTS, **custom}
    assert 0 < cfg['test_fraction'] < 0.5
    assert 0 < cfg['validation_fraction'] < 0.5
    assert 0 < cfg['threshold'] < 1
    assert cfg['image_size'] >= 32
    return cfg
