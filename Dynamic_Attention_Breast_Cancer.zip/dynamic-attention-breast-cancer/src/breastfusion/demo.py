"""Nonclinical SYNTHETIC IMAGE TEST FIXTURE. Never interpret as mammograms."""
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image,ImageDraw

def make_demo(outdir='data/demo',n=60,size=96,seed=9001):
    outdir=Path(outdir); image_dir=outdir/'images';image_dir.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(seed)
    records=[]
    for i in range(n):
        y=i%2
        yy,xx=np.ogrid[:size,:size]
        # Gradient/noise and a *synthetic shape*: NOT biological or clinical.
        background=40+20*xx/size+15*yy/size+rng.normal(0,14,(size,size))
        x0=int(size/2+rng.normal(0,size*.09)); y0=int(size/2+rng.normal(0,size*.09))
        r=int(size*(.19 if y else .08))
        obj=(xx-x0)**2+(yy-y0)**2<r*r
        background[obj]+=70 if y else 18
        im=Image.fromarray(np.clip(background,0,255).astype(np.uint8),'L')
        fname=f'images/case_{i:04d}.png'; im.save(outdir/fname)
        records.append(dict(cohort='demo',patient_id=f'DEMO_{i:04d}',image_path=fname,label=y,
               age=30+i%45 if i%9 else np.nan,
               breast_density=(i%4)+1 if i%7 else np.nan,
               bmi=np.nan,menopausal_status=np.nan,
               lesion_mask_path='',morphology=''))
    pd.DataFrame(records).to_csv(outdir/'manifest.csv',index=False)
    (outdir/'SYNTHETIC_NOT_CLINICAL.txt').write_text(
        'Generated geometric patterns, not mammograms. Results cannot reproduce the paper.\n')
    return outdir/'manifest.csv'
