"""TensorFlow/Keras multimodal classifier and comparison fusion operators.
Manuscript-proposed model is exact at the layer/parameter-count level (422,945).
Baseline fusion operators are explicit implementable research interpretations;
compare operator definitions with original study code before making reproduction claims.
"""
import tensorflow as tf

METHODS = ['proposed','image_only','clinical_only','early','tfn','lmf','gmu',
           'film','daft','cross_attention','no_augmentation','no_regularization']

class DynamicFusionNet(tf.keras.Model):
    def __init__(self, method='proposed', attention_dim=32, dropout=.4, **kwargs):
        super().__init__(**kwargs)
        if method not in METHODS: raise ValueError(f'Unknown method {method}, expected {METHODS}')
        self.method=method
        h=tf.keras.initializers.HeNormal
        self.conv1=tf.keras.layers.Conv2D(64,3,padding='same',activation='relu',kernel_initializer=h())
        self.conv2=tf.keras.layers.Conv2D(128,3,padding='same',activation='relu',kernel_initializer=h())
        self.conv3=tf.keras.layers.Conv2D(256,3,padding='same',activation='relu',kernel_initializer=h())
        self.pool=tf.keras.layers.MaxPooling2D(2)
        self.gap=tf.keras.layers.GlobalAveragePooling2D()
        self.proj_image=tf.keras.layers.Dense(128,activation='relu',kernel_initializer=h())
        self.proj_clin=tf.keras.layers.Dense(64,activation='relu',kernel_initializer=h())
        self.att_img=tf.keras.layers.Dense(attention_dim,activation='tanh')
        self.att_clin=tf.keras.layers.Dense(attention_dim,activation='tanh')
        self.relevance=self.add_weight(name='shared_relevance',shape=(attention_dim,),initializer='glorot_uniform',trainable=True)
        self.fuse=tf.keras.layers.Dense(64,activation='relu',kernel_initializer=h())
        self.dropout=tf.keras.layers.Dropout(dropout)
        self.output_logits=tf.keras.layers.Dense(1,kernel_initializer=h())
        # Feature-level baselines
        self.tfn_i=tf.keras.layers.Dense(16,activation='tanh')
        self.tfn_c=tf.keras.layers.Dense(16,activation='tanh')
        self.lmf_i=tf.keras.layers.Dense(4*64)
        self.lmf_c=tf.keras.layers.Dense(4*64)
        self.gmu_img=tf.keras.layers.Dense(64,activation='tanh')
        self.gmu_clin=tf.keras.layers.Dense(64,activation='tanh')
        self.gmu_gate=tf.keras.layers.Dense(64,activation='sigmoid')
        # Intermediate fusion alternatives
        self.film_scale=tf.keras.layers.Dense(256)
        self.film_shift=tf.keras.layers.Dense(256)
        self.daft_scale=tf.keras.layers.Dense(256)
        self.daft_shift=tf.keras.layers.Dense(256)
        self.cross_attention=tf.keras.layers.MultiHeadAttention(num_heads=4,key_dim=64)
        self.cross_query=tf.keras.layers.Dense(256)
        self.cross_output=tf.keras.layers.Dense(192,activation='relu')

    def call(self, inputs, training=False):
        image,clin=inputs
        fmap=None
        if self.method!='clinical_only':
            fmap=self.pool(self.conv3(self.pool(self.conv2(self.pool(self.conv1(image))))))
        c=self.proj_clin(clin) if self.method!='image_only' else None
        if self.method=='film':
            scale=1+tf.tanh(self.film_scale(c))
            fmap=fmap*scale[:,None,None,:]+self.film_shift(c)[:,None,None,:]
        elif self.method=='daft':
            pooled=self.gap(fmap)
            cond=tf.concat([pooled,c],axis=-1)
            fmap=fmap*(1+tf.tanh(self.daft_scale(cond)))[:,None,None,:]+self.daft_shift(cond)[:,None,None,:]
        i=self.proj_image(self.gap(fmap)) if fmap is not None else None
        bs=tf.shape(i)[0]
        if self.method=='image_only':
            fused=i; weights=tf.concat([tf.ones([bs,1]),tf.zeros([bs,1])],axis=1)
        elif self.method=='clinical_only':
            fused=c; weights=tf.concat([tf.zeros([bs,1]),tf.ones([bs,1])],axis=1)
        elif self.method in ('early','film','daft'):
            fused=tf.concat([i,c],axis=-1)
            weights=tf.fill([bs,2],.5)
        elif self.method=='tfn':
            ix=tf.concat([self.tfn_i(i),tf.ones([bs,1])],axis=-1)
            cx=tf.concat([self.tfn_c(c),tf.ones([bs,1])],axis=-1)
            fused=tf.reshape(ix[:,:,None]*cx[:,None,:],[bs,17*17])
            weights=tf.fill([bs,2],.5)
        elif self.method=='lmf':
            a=tf.reshape(self.lmf_i(i),[bs,4,64]); b=tf.reshape(self.lmf_c(c),[bs,4,64])
            fused=tf.reduce_sum(a*b,axis=1)
            weights=tf.fill([bs,2],.5)
        elif self.method=='gmu':
            gate=self.gmu_gate(tf.concat([i,c],axis=-1))
            fused=gate*self.gmu_img(i)+(1-gate)*self.gmu_clin(c)
            weights=tf.concat([tf.reduce_mean(gate,1,keepdims=True),
                               1-tf.reduce_mean(gate,1,keepdims=True)],axis=-1)
        elif self.method=='cross_attention':
            tokens=tf.reshape(fmap,[bs,-1,256])
            attended=self.cross_attention(self.cross_query(c)[:,None,:],tokens)
            fused=self.cross_output(tf.concat([tf.squeeze(attended,axis=1),i,c],axis=-1))
            weights=tf.fill([bs,2],.5)
        else:  # proposed patient-dependent 2-logit attention
            scores=tf.concat([
                tf.reduce_sum(self.att_img(i)*self.relevance,axis=-1,keepdims=True),
                tf.reduce_sum(self.att_clin(c)*self.relevance,axis=-1,keepdims=True)
            ],axis=1)
            weights=tf.nn.softmax(scores,axis=1)
            fused=tf.concat([i*weights[:,0:1],c*weights[:,1:2]],axis=-1)
        fused=self.fuse(fused)
        if self.method!='no_regularization': fused=self.dropout(fused,training=training)
        logits=tf.squeeze(self.output_logits(fused),axis=-1)
        return {'logits':logits,'weights':weights,'feature_map':fmap}

def build_model(method='proposed', image_size=224, attention_dim=32, dropout=.4):
    model=DynamicFusionNet(method=method,attention_dim=attention_dim,dropout=dropout)
    model((tf.zeros([1,image_size,image_size,3]),tf.zeros([1,8])),training=False)
    if method=='proposed':
        assert model.count_params()==422945, f'Architecture drift: {model.count_params()} != 422945'
    return model
