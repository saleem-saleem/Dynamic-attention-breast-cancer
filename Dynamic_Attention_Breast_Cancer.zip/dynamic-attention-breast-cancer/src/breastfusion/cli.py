"""Command-line entry point. All run outputs are newly computed from supplied data."""
import argparse
from pathlib import Path
import pandas as pd
import numpy as np
from .config import load_config
from .data import read_manifest,make_splits,cv_splits
from .utils import write_json

ALL_METHODS=['proposed','image_only','clinical_only','early','late','tfn','lmf','gmu',
             'film','daft','cross_attention']

def _fit_one(parts,cfg,cohort,method,seed,folder):
    from .training import train_model,evaluate_model
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    if method=='late':
        # Strict late fusion: train the unimodal models independently and average calibrated scores.
        im,ip,it,_=train_model(parts['train'],parts['val'],cfg,'image_only',seed,folder/'image')
        cm,cp,ct,_=train_model(parts['train'],parts['val'],cfg,'clinical_only',seed,folder/'clinical')
        _,_,a=evaluate_model(im,ip,it,parts['test'],cfg,cohort,'image_only',seed)
        _,_,b=evaluate_model(cm,cp,ct,parts['test'],cfg,cohort,'clinical_only',seed)
        from .metrics import evaluate_predictions
        p=(a.probability.to_numpy()+b.probability.to_numpy())/2
        result=a.copy();result['model']='late';result['probability']=p
        result['p_uncalibrated']=(a.p_uncalibrated+b.p_uncalibrated)/2
        result['predicted']=(p>=cfg['threshold']).astype(int)
        result['alpha_image']=.5;result['beta_clinical']=.5
        metric=evaluate_predictions(result.label,p,cfg['threshold'],
                bins=5 if cohort=='mias' else 10,equal_mass=cohort=='mias')
        raw=evaluate_predictions(result.label,result.p_uncalibrated,cfg['threshold'],
                bins=5 if cohort=='mias' else 10,equal_mass=cohort=='mias')
    else:
        model,prep,temp,_=train_model(parts['train'],parts['val'],cfg,method,seed,folder)
        metric,raw,result=evaluate_model(model,prep,temp,parts['test'],cfg,cohort,method,seed)
    result.to_csv(folder/'predictions.csv',index=False)
    write_json(folder/'metrics.json',{'calibrated':metric,'uncalibrated':raw,'method':method,'seed':seed,
                'warning':'This file is from a new run, not a reproduction of manuscript numbers.'})
    return metric,raw,result

def run_a(df,cfg,cohort,model,output):
    parts=make_splits(df,cfg['split_seed'],cfg['test_fraction'],cfg['validation_fraction'])
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    for name,piece in parts.items():
        # Only safe patient IDs are written. Never commit these real-data split files.
        piece[['cohort','patient_id','label']].to_csv(output/f'{name}_patient_manifest.csv',index=False)
    models=ALL_METHODS if model=='all' else [model]
    metrics=[];predictions=[]
    for name in models:
        for seed in cfg['seeds']:
            folder=output/cohort/name/f'seed_{seed}'
            met,_,pred=_fit_one(parts,cfg,cohort,name,seed,folder)
            row={'cohort':cohort,'model':name,'seed':seed,**met}
            metrics.append(row);predictions.append(pred)
            print(f'{cohort}/{name}/seed{seed}: AUC={met["auc"]:.4f}, accuracy={met["accuracy"]:.4f}')
    pd.DataFrame(metrics).to_csv(output/'protocol_A_metrics.csv',index=False)
    pd.concat(predictions,ignore_index=True).to_csv(output/'protocol_A_predictions.csv',index=False)
    write_json(output/'protocol_A_settings.json',{'protocol':'A','config':cfg,'models':models,
        'note':'Test kept fixed for all seeds and models; results calculated, not prefilled.'})

def run_b(df,cfg,cohort,model,output):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    # Protocol B uses only development patients from the locked test split.
    frozen=make_splits(df,cfg['split_seed'],cfg['test_fraction'],cfg['validation_fraction'])
    dev=pd.concat([frozen['train'],frozen['val']],ignore_index=True)
    models=ALL_METHODS if model=='all' else [model]
    metrics=[]
    for fold,parts in cv_splits(dev,cfg['cv_seed']):
        for name in models:
            # CV uses fixed seed to isolate fold effects; development only.
            met,_,_= _fit_one(parts,cfg,cohort,name,11,output/cohort/name/f'fold_{fold}')
            metrics.append({'cohort':cohort,'model':name,'fold':fold,**met})
            print(f'{cohort}/{name}/fold{fold}: AUC={met["auc"]:.4f}')
    pd.DataFrame(metrics).to_csv(output/'protocol_B_metrics.csv',index=False)
    write_json(output/'protocol_B_settings.json',{'protocol':'B','config':cfg,
        'note':'Development-only cross validation. These folds must not be reported as independent test-set results.'})

def summarize(input_csv,outfile):
    df=pd.read_csv(input_csv)
    columns=[c for c in ('accuracy','f1','recall','specificity','auc','ece','nll','brier') if c in df]
    grouping=['cohort','model']
    rows=[]
    for key,group in df.groupby(grouping):
        row={'cohort':key[0],'model':key[1],'runs':len(group)}
        for col in columns:
            row[f'{col}_mean']=float(group[col].mean())
            row[f'{col}_sd']=float(group[col].std(ddof=1)) if len(group)>1 else float('nan')
        rows.append(row)
    pd.DataFrame(rows).to_csv(outfile,index=False)
    print(f'Saved {outfile}')

def main(argv=None):
    p=argparse.ArgumentParser(description='BreastFusion reproducibility tools (research only)')
    sub=p.add_subparsers(dest='command',required=True)
    d=sub.add_parser('make-demo',help='Create synthetic geometric test images; NOT patient data')
    d.add_argument('--out',default='data/demo');d.add_argument('--count',type=int,default=60)
    for name in ('train','crossval'):
        q=sub.add_parser(name)
        q.add_argument('--manifest',required=True)
        q.add_argument('--cohort',required=True,choices=['cbis','mias','private','demo'])
        q.add_argument('--config',default='configs/manuscript.yaml')
        q.add_argument('--model',choices=ALL_METHODS+['all'],default='proposed')
        q.add_argument('--out',default='outputs')
    s=sub.add_parser('summarize');s.add_argument('--metrics',required=True);s.add_argument('--out',required=True)
    plot=sub.add_parser('plots');plot.add_argument('--predictions',required=True);plot.add_argument('--out',default='outputs/figures')
    stat=sub.add_parser('paired-tests');stat.add_argument('--metrics',required=True);stat.add_argument('--out',default='outputs/paired_statistics.csv')
    args=p.parse_args(argv)
    if args.command=='make-demo':
        from .demo import make_demo
        print('SYNTHETIC ONLY:',make_demo(args.out,args.count));return
    if args.command in ('train','crossval'):
        cfg=load_config(args.config)
        df=read_manifest(args.manifest,args.cohort)
        fn=run_a if args.command=='train' else run_b
        fn(df,cfg,args.cohort,args.model,args.out); return
    if args.command=='summarize':summarize(args.metrics,args.out);return
    if args.command=='plots':
        from .plots import save_plots
        save_plots(args.predictions,args.out);return
    if args.command=='paired-tests':
        from .analyses import paired_comparisons
        paired_comparisons(args.metrics,args.out);return

if __name__=='__main__':main()
