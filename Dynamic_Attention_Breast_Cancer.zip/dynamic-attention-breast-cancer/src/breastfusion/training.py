"""Manual Keras training with validation-only early stopping and temperature scaling."""
import copy
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from .model import build_model
from .data import ClinicalPreprocessor, make_tf_dataset
from .metrics import evaluate_predictions
from .utils import set_seed, write_json

def binary_ce(y, logits):
    import tensorflow as tf
    return tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(labels=tf.cast(y,tf.float32),
                                                                  logits=logits))

def fit_temperature(validation_logits, validation_y):
    """Fit positive temperature only on validation labels (scalar bounded optimizer)."""
    z=np.asarray(validation_logits,dtype=float); y=np.asarray(validation_y,dtype=float)
    if len(np.unique(y))<2: raise ValueError('Both labels needed for calibration')
    from scipy.special import expit, xlogy
    def nll(logtemp):
        p=np.clip(expit(z/np.exp(logtemp)),1e-8,1-1e-8)
        return float(-np.mean(xlogy(y,p)+xlogy(1-y,1-p)))
    result=minimize_scalar(nll,bounds=(-3,3),method='bounded')
    return float(np.exp(result.x))

def predictions(model,ds):
    import tensorflow as tf
    logits=[]; weights=[]; yy=[]
    for images,clinical,y in ds:
        output=model((images,clinical),training=False)
        logits.extend(np.asarray(output['logits']).reshape(-1).tolist())
        weights.extend(np.asarray(output['weights']).tolist())
        yy.extend(np.asarray(y).reshape(-1).tolist())
    return np.asarray(logits),np.asarray(weights),np.asarray(yy,dtype=int)

def train_model(df_train,df_val,cfg,method,seed,output_dir=None):
    import tensorflow as tf
    set_seed(seed)
    prep=ClinicalPreprocessor().fit(df_train)
    it=prep.transform(df_train);iv=prep.transform(df_val)
    tr=make_tf_dataset(df_train,it,cfg['image_size'],cfg['batch_size'],True,seed,
                       cfg['rotation_factor'] if method!='no_augmentation' else 0.0,
                       bool(cfg['augment_flip']) if method!='no_augmentation' else False)
    # If augmentation ablated, do not apply either flip or rotation:
    if method=='no_augmentation':
        tr=make_tf_dataset(df_train,it,cfg['image_size'],cfg['batch_size'],False,seed)
    valid=make_tf_dataset(df_val,iv,cfg['image_size'],cfg['batch_size'])
    model=build_model(method,cfg['image_size'],cfg['attention_dim'],cfg['dropout'])
    optimizer=tf.keras.optimizers.AdamW(learning_rate=cfg['learning_rate'],
        beta_1=.9,beta_2=.999,epsilon=cfg['adam_epsilon'],
        weight_decay=0.0 if method=='no_regularization' else cfg['weight_decay'])
    best=np.inf;weights=None;stall=0;history=[]
    for epoch in range(1,int(cfg['max_epochs'])+1):
        batch_losses=[]; tr_correct=0;tr_num=0
        for images,clin,y in tr:
            with tf.GradientTape() as tape:
                out=model((images,clin),training=True)
                loss=binary_ce(y,out['logits'])
            grads=tape.gradient(loss,model.trainable_variables)
            optimizer.apply_gradients([(g,v) for g,v in zip(grads,model.trainable_variables) if g is not None])
            batch_losses.append(float(loss.numpy()))
            tr_correct+=int(tf.reduce_sum(tf.cast(tf.equal(tf.cast(tf.sigmoid(out['logits'])>=.5,tf.float32),y),tf.int32)))
            tr_num+=int(y.shape[0])
        val_z,_,val_y=predictions(model,valid)
        from scipy.special import expit
        val_probs=expit(val_z)
        val_loss=float(np.mean(np.logaddexp(0,val_z)-val_y*val_z))
        record={'epoch':epoch,'train_loss':float(np.mean(batch_losses)),
               'train_accuracy':tr_correct/max(tr_num,1),
               'val_loss':val_loss,'val_accuracy':float(np.mean((val_probs>=.5)==val_y))}
        history.append(record)
        if val_loss<best-1e-7:
            best=val_loss;weights=copy.deepcopy(model.get_weights());stall=0
        else:
            stall+=1
            if stall>=cfg['patience']: break
    model.set_weights(weights)
    val_z,_,val_y=predictions(model,valid)
    temperature=fit_temperature(val_z,val_y)
    if output_dir is not None:
        from pathlib import Path
        folder=Path(output_dir); folder.mkdir(parents=True,exist_ok=True)
        model.save_weights(str(folder/'model.weights.h5'))
        pd.DataFrame(history).to_csv(folder/'training_history.csv',index=False)
        write_json(folder/'clinical_transform.json',prep.to_dict())
        write_json(folder/'fit_metadata.json',{'seed':seed,'method':method,'temperature':temperature,
           'best_epoch':int(np.argmin([x['val_loss'] for x in history])+1),
           'epochs_run':len(history),'architecture_params':model.count_params()})
    return model,prep,temperature,history

def evaluate_model(model,prep,temperature,df,cfg,cohort,method,seed):
    from scipy.special import expit
    x=prep.transform(df)
    dataset=make_tf_dataset(df,x,cfg['image_size'],cfg['batch_size'])
    logits,weights,y=predictions(model,dataset)
    p=expit(logits/temperature)
    raw=expit(logits)
    bins=5 if cohort=='mias' else 10
    metrics=evaluate_predictions(y,p,cfg['threshold'],bins,equal_mass=(cohort=='mias'))
    raw_metrics=evaluate_predictions(y,raw,cfg['threshold'],bins,equal_mass=(cohort=='mias'))
    results=df[['cohort','patient_id','label']].reset_index(drop=True).copy()
    results['model']=method;results['seed']=seed
    results['logit']=logits; results['p_uncalibrated']=raw
    results['probability']=p;results['predicted']=(p>=cfg['threshold']).astype(int)
    results['alpha_image']=weights[:,0];results['beta_clinical']=weights[:,1]
    return metrics,raw_metrics,results
