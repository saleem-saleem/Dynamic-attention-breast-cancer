#!/usr/bin/env bash
set -euo pipefail
MANIFEST="${1:?Usage: bash scripts/reproduce_all.sh /secure/manifest.csv}"
for COHORT in cbis mias private; do
  python scripts/verify_manifest.py --manifest "$MANIFEST" --cohort "$COHORT"
  python -m breastfusion crossval --manifest "$MANIFEST" --cohort "$COHORT" --model proposed --config configs/manuscript.yaml --out "outputs/${COHORT}_cv"
  python -m breastfusion train --manifest "$MANIFEST" --cohort "$COHORT" --model all --config configs/manuscript.yaml --out "outputs/${COHORT}_A"
  python -m breastfusion summarize --metrics "outputs/${COHORT}_A/protocol_A_metrics.csv" --out "outputs/${COHORT}_A/summary.csv"
  python -m breastfusion paired-tests --metrics "outputs/${COHORT}_A/protocol_A_metrics.csv" --out "outputs/${COHORT}_A/paired_tests.csv"
  python -m breastfusion plots --predictions "outputs/${COHORT}_A/protocol_A_predictions.csv" --out "outputs/${COHORT}_A/figures"
done
