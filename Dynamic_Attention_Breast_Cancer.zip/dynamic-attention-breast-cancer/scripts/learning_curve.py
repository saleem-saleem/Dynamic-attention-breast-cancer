#!/usr/bin/env python3
"""Retrain on nested, patient-stratified fractions while keeping validation/test fixed."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from breastfusion.config import load_config
from breastfusion.data import read_manifest,make_splits
from breastfusion.cli import _fit_one

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--manifest',required=True)
 p.add_argument('--cohort',required=True);p.add_argument('--config',default='configs/manuscript.yaml')
 p.add_argument('--out',default='outputs/learning_curve')
 p.add_argument('--fractions',nargs='+',type=float,default=[.25,.4,.6,.8,1.0])
 a=p.parse_args();cfg=load_config(a.config)
 full=make_splits(read_manifest(a.manifest,a.cohort),cfg['split_seed'],cfg['test_fraction'],cfg['validation_fraction'])
 patients=full['train'].groupby('patient_id',as_index=False).label.first()
 rows=[];out=Path(a.out)
 for frac in a.fractions:
  if not 0<frac<=1:raise ValueError('Fraction must be within (0,1]')
  if frac<1:
   count=max(4,int(round(len(patients)*frac)))
   pids,_=train_test_split(patients.patient_id,train_size=count,
             stratify=patients.label,random_state=cfg['split_seed'])
   tr=full['train'][full['train'].patient_id.isin(pids)].copy()
  else:tr=full['train']
  parts={**full,'train':tr}
  for seed in cfg['seeds']:
   metrics,_,_= _fit_one(parts,cfg,a.cohort,'proposed',seed,out/f'fraction_{frac:.2f}'/f'seed_{seed}')
   rows.append({'fraction':frac,'seed':seed,'training_patients':tr.patient_id.nunique(),**metrics})
 out.mkdir(parents=True,exist_ok=True)
 pd.DataFrame(rows).to_csv(out/'learning_curve_metrics.csv',index=False)
