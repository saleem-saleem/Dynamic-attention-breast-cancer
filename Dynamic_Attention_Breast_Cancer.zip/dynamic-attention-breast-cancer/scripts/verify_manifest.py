#!/usr/bin/env python3
"""Validate paths/class ratios/groups before expensive training."""
import argparse,json
from pathlib import Path
from breastfusion.data import read_manifest,make_splits

if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('--manifest',required=True);p.add_argument('--cohort',required=True)
 args=p.parse_args()
 df=read_manifest(args.manifest,args.cohort)
 missing=[x for x in df.image_path if not Path(x).is_file()]
 print('rows:',len(df),'patients:',df.patient_id.nunique(),
       'class_counts:',df.label.value_counts().to_dict(), 'missing_files:',len(missing))
 if missing:raise SystemExit('Bad image paths: '+repr(missing[:3]))
 s=make_splits(df)
 for k,v in s.items():print(k,len(v),'images',v.patient_id.nunique(),'patients',v.label.value_counts().to_dict())
