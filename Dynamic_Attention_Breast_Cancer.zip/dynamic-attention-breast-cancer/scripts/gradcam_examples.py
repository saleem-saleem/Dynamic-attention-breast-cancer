#!/usr/bin/env python3
"""Render Grad-CAM for cases with optional masks; uses a trained model, not sample figures."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from breastfusion.model import build_model
from breastfusion.data import read_manifest,ClinicalPreprocessor,load_image_np
from breastfusion.config import load_config
from breastfusion.explain import gradcam,pointing_game,localization_iou

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source-run',required=True);p.add_argument('--manifest',required=True)
 p.add_argument('--cohort',required=True);p.add_argument('--config',default='configs/manuscript.yaml')
 p.add_argument('--out',default='outputs/gradcam');p.add_argument('--max-cases',type=int,default=12)
 a=p.parse_args();folder=Path(a.source_run);cfg=load_config(a.config)
 meta=json.loads((folder/'fit_metadata.json').read_text())
 model=build_model(meta['method'],cfg['image_size'],cfg['attention_dim'],cfg['dropout'])
 model.load_weights(str(folder/'model.weights.h5'))
 prep=ClinicalPreprocessor();prep.params=json.loads((folder/'clinical_transform.json').read_text())['parameters']
 df=read_manifest(a.manifest,a.cohort);out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 rows=[]
 for i in range(min(a.max_cases,len(df))):
  row=df.iloc[i]
  image=load_image_np(row.image_path,cfg['image_size'])
  clin=prep.transform(df.iloc[[i]])[0]
  cam=gradcam(model,image,clin)
  fig,ax=plt.subplots(figsize=(5,5))
  ax.imshow(np.clip(image*.25+.5,0,1));ax.imshow(Image.fromarray((cam*255).astype('uint8')).resize(
    (image.shape[1],image.shape[0]),Image.Resampling.BILINEAR),cmap='inferno',alpha=.35)
  ax.set_axis_off();fig.tight_layout()
  fig.savefig(out/f'case_{i:04d}_gradcam.png',dpi=200);plt.close(fig)
  record={'case_index':i,'pointing_game':np.nan,'localization_iou':np.nan}
  if isinstance(row.lesion_mask_path,str) and Path(row.lesion_mask_path).is_file():
   gt=np.array(Image.open(row.lesion_mask_path).convert('L'))
   record.update(pointing_game=pointing_game(cam,gt),localization_iou=localization_iou(cam,gt))
  rows.append(record)
 pd.DataFrame(rows).to_csv(out/'localization_metrics.csv',index=False)
 print('Wrote actual Grad-CAM overlays:',out)
