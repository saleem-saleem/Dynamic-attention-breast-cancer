#!/usr/bin/env python3
"""Additional descriptive analyses on locked test predictions. No threshold tuning."""
import argparse
from pathlib import Path
import pandas as pd
from breastfusion.analyses import threshold_outputs
from breastfusion.delong import correlated_delong

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--predictions',required=True);p.add_argument('--out',default='outputs/posthoc')
 args=p.parse_args();data=pd.read_csv(args.predictions);out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 threshold_outputs(args.predictions,out)
 rows=[]
 for (cohort,seed),block in data.groupby(['cohort','seed']):
  if 'proposed' not in set(block.model):continue
  a=block[block.model=='proposed'].set_index('patient_id').sort_index()
  for competitor in sorted(set(block.model)-{'proposed'}):
   b=block[block.model==competitor].set_index('patient_id').sort_index()
   if not a.index.is_unique or not b.index.is_unique:
    # DeLong requires independent patients. If duplicates exist, skip rather than pretend.
    continue
   common=a.index.intersection(b.index)
   if len(common)<6:continue
   if not (a.loc[common,'label'].to_numpy()==b.loc[common,'label'].to_numpy()).all():raise ValueError('Label mismatch')
   stat=correlated_delong(a.loc[common,'label'].to_numpy(),a.loc[common,'probability'].to_numpy(),b.loc[common,'probability'].to_numpy())
   rows.append({'cohort':cohort,'seed':seed,'vs':competitor,**stat})
 pd.DataFrame(rows).to_csv(out/'delong_single_seed.csv',index=False)
 print('Created descriptive posthoc reports in',out)
