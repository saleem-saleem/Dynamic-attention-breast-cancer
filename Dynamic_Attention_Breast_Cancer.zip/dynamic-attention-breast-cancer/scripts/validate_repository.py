#!/usr/bin/env python3
"""Validate repository source and small data utilities. Does not claim neural training validation."""
from pathlib import Path
import ast
import subprocess
import sys

root=Path(__file__).resolve().parent.parent
files=list((root/'src').rglob('*.py'))+list((root/'scripts').glob('*.py'))+list((root/'tests').glob('*.py'))
for f in files:
    ast.parse(f.read_text(encoding='utf8'),filename=str(f))
print('Source parse check PASS:',len(files),'Python files')
cmd=[sys.executable,'-m','pytest','-q',str(root/'tests')]
proc=subprocess.run(cmd,cwd=str(root),env=__import__('os').environ|{'PYTHONPATH':str(root/'src')})
raise SystemExit(proc.returncode)
