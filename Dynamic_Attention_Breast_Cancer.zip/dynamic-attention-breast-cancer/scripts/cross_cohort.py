#!/usr/bin/env python3
"""Zero-shot cohort transfer, without fine-tuning or recalibration.
Run only with source-cohort checkpoints and authorized target manifest.
"""
import argparse,json
from pathlib import Path
from breastfusion.model import build_model
from breastfusion.data import read_manifest,ClinicalPreprocessor
from breastfusion.training import evaluate_model
from breastfusion.config import load_config
from breastfusion.utils import write_json

if __name__=='__main__':
 p=argparse.ArgumentParser()
 p.add_argument('--source-run',required=True,help='outputs/source/model/seed_N folder')
 p.add_argument('--target-manifest',required=True)
 p.add_argument('--target-cohort',required=True,choices=['cbis','mias','private'])
 p.add_argument('--config',default='configs/manuscript.yaml')
 p.add_argument('--out',required=True)
 a=p.parse_args();cfg=load_config(a.config)
 folder=Path(a.source_run)
 metadata=json.loads((folder/'fit_metadata.json').read_text())
 clinical=json.loads((folder/'clinical_transform.json').read_text())
 prep=ClinicalPreprocessor();prep.params=clinical['parameters'];prep.available=[k for k,v in prep.params.items() if v['available']]
 source_model=build_model(metadata['method'],cfg['image_size'],cfg['attention_dim'],cfg['dropout'])
 source_model.load_weights(str(folder/'model.weights.h5'))
 target=read_manifest(a.target_manifest,a.target_cohort)
 # Call on authorized test-only manifest, do not inadvertently test on target training samples.
 metric,raw,pred=evaluate_model(source_model,prep,metadata['temperature'],target,cfg,
                   a.target_cohort,metadata['method'],metadata['seed'])
 out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
 pred.to_csv(out/'transfer_predictions.csv',index=False)
 write_json(out/'transfer_metrics.json',{'metrics':metric,'source_run':str(folder),'target':a.target_cohort,
      'warning':'Transferred source calibration; no target adaptation; ensure target test-only manifest.'})
 print('Transfer AUC:',metric['auc'])
