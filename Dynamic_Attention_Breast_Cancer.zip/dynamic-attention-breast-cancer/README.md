# Dynamic Attention Fusion for Mammography and Incomplete Clinical Data

Research code accompanying the methodology in **“A Dynamic Attention Fusion Framework for Heterogeneous and Incomplete Multimodal Clinical Data: Application to Breast Cancer Detection.”**

**Status:** independent reference implementation based on the uploaded revised manuscript, not a release of the manuscript's original training code or experimental data. **The manuscript's reported AUCs (CBIS-DDSM 0.947; MIAS 0.887; private cohort 0.958) are NOT reproduced or fabricated here.** They may be compared against new runs only after confirming identical cohort selection, splits and preprocessing.

> Research and educational use only. Not a clinical diagnostic system. No patient images or records are distributed.

## What is implemented?

- **Image encoder:** three 3×3 convolution blocks (64/128/256 filters, ReLU, 2×2 pooling), global average pooling, Dense(128).
- **Clinical encoder:** `[age, breast_density, bmi, menopausal_status]` + four observed/missingness indicators; Dense(64).
- **Patient-dependent attention:** 32-dimensional tanh projections, shared 32-element scoring vector, softmax image and clinical weights (`alpha + beta = 1`), weighted concatenation, Dense(64), dropout(0.40), binary output.
- **Exactly 422,945 parameters** in the proposed model, including 6,240 attention parameters (checked by an automated test).
- **Validation calibration:** temperature scaling on logits, fitted with validation NLL, not on the locked test set.
- **Protocol A:** patient-disjoint train/validation/test, fixed split seed 2025, repeats 11/22/33/44/55.
- **Protocol B:** five development-set folds (seed 2026); the locked test set is excluded.
- **Competitors:** image-only, clinical-only, early fusion, late fusion, TFN, LMF, GMU, FiLM, DAFT and cross-modal attention; plus attention, augmentation and regularization ablations.
- **Metrics and analyses:** confusion counts, accuracy, precision, recall, F1, balanced accuracy, MCC, ROC-/PR-AUC, NLL, ECE/MCE, adaptive bins, Brier, paired comparisons with Holm, patient bootstrap, modality removal, missingness, Grad-CAM, decision curves, selective prediction, and figures.

## Setup

Python **3.11** recommended. For GPU use a compatible TensorFlow/CUDA setup; CPU works for small examples.

```bash
git clone <YOUR-REPOSITORY-URL>
cd dynamic-attention-breast-cancer
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e '.[dev]'
pytest -q
```

## Five-minute test: SYNTHETIC DEMONSTRATION ONLY

The demo generates geometric shapes **not mammograms**. It checks that code runs; numerical results have no medical interpretation.

```bash
python -m breastfusion make-demo --out data/demo --count 60
python -m breastfusion train --manifest data/demo/manifest.csv --cohort demo --model proposed --config configs/smoke.yaml --out outputs/demo
python -m breastfusion summarize --metrics outputs/demo/protocol_A_metrics.csv --out outputs/demo/summary.csv
python -m breastfusion plots --predictions outputs/demo/protocol_A_predictions.csv --out outputs/demo/figures
```

For reproducibility of the full architecture at **224×224** use `configs/manuscript.yaml`. Training 11 models × 5 seeds per cohort is resource-intensive and not a quick demonstration.

## Working with real data

1. Obtain datasets through the official sources and comply with institutional/data-use restrictions. **No datasets are included.**
2. Export a de-identified manifest following `data/templates/manifest_example.csv`. `patient_id` must be stable across all views/crops of one patient; `label` must be **0 benign, 1 malignant**; paths may point to PNG, JPEG, TIFF, PGM or DICOM.
3. For CBIS-DDSM use the cohort label `cbis`, for mini-MIAS `mias`, and for the private data `private`. For MIAS reproduce the study's inclusion criterion: **115 abnormal images, excluding normal cases**. No guessing patient identities from image filenames.
4. Real clinical variables must come only from permitted sources. CBIS age fields may require case-file joins; do not synthesize absent age or BMI measurements and call them real.
5. If you have multiple mammograms per patient, split patients, **not images**. Exact 70/15/15 image counts are not guaranteed when grouping patients.

```bash
python -m breastfusion train --manifest /secure/cohort_manifest.csv --cohort cbis --model proposed --config configs/manuscript.yaml --out outputs/cbis
python -m breastfusion train --manifest /secure/cohort_manifest.csv --cohort cbis --model all --config configs/manuscript.yaml --out outputs/cbis_all
python -m breastfusion crossval --manifest /secure/cohort_manifest.csv --cohort cbis --model proposed --config configs/manuscript.yaml --out outputs/cbis_cv
python -m breastfusion paired-tests --metrics outputs/cbis_all/protocol_A_metrics.csv --out outputs/cbis_all/paired_statistics.csv
```

Outputs: `model.weights.h5`, train-only clinical transformation, temperature, history, per-case predictions with case-specific weights, actual metrics, aggregate tables, and plotting-ready PNGs. Do not commit outputs that contain patient IDs.

## Experiment design

**Protocol A** creates the locked patient-level test set first. A patient-level validation set is then separated from the remainder. This order prevents data leakage; scaling, imputation, model selection and calibration use only allowed partitions. A new model is trained for every seed. The test split stays fixed across methods and seeds.

**Protocol B** runs five stratified patient folds **on the development portion alone**. It is intended for hyperparameter development; test-set reports must use Protocol A.

**Ablation examples:** `--model early` is without attention; `--model image_only` removes the clinical branch; `--model no_augmentation` disables image augmentation; `--model no_regularization` removes dropout and AdamW decay. Exact per-ablation statistical comparisons require matching training seeds. Other feature-availability ablations may be run by creating controlled new manifests and maintaining identical splits.

**Post-hoc analyses** are descriptive and should never select a deployment threshold based on the locked test set. See `src/breastfusion/analyses.py` and `src/breastfusion/explain.py` for direct callable functions, and `docs/IMPLEMENTATION.md` for limitations.

## Dataset sources

- **CBIS-DDSM:** [The Cancer Imaging Archive](https://doi.org/10.7937/K9/TCIA.2016.7O02S9CY)
- **mini-MIAS:** [University of Cambridge Apollo Repository](https://doi.org/10.17863/CAM.105113)
- **Private cohort:** not released; requires institutional permission and patient-privacy compliance.

## Reproducibility checklist

- [ ] Dataset checksum and patient-level manifest validated
- [ ] Identical cohort inclusion criteria to manuscript
- [ ] Image scaling/windowing verified against original code
- [ ] Clinical category encoding verified
- [ ] Fixed development/test partition stored securely
- [ ] Preprocessing fitted on training patients only
- [ ] Model parameter count matches 422,945
- [ ] 5 training seeds all completed and individually logged
- [ ] Temperature fitted on validation only
- [ ] Baselines use same splits and comparable training budgets
- [ ] All figures derived from actual prediction/log files
- [ ] No simulated/demo results used as observed results

## Limits and differences

See [Implementation & provenance notes](docs/IMPLEMENTATION.md). Some original preprocessing choices and detailed baseline operators are not fully specified in the manuscript, so **a run of this reference implementation is not guaranteed to reproduce the published performance**. Inference is for controlled offline research only. Data privacy is the responsibility of the executing institution.

## Citation

Use `CITATION.cff` after authors confirm the publication metadata. The code is available under the MIT license; dataset terms apply independently.

## Extended scripts

```bash
# Verify file paths, case counts, patient-level split before a run
python scripts/verify_manifest.py --manifest /secure/cohort_manifest.csv --cohort cbis

# Run all three cohorts (requires authorized datasets and extensive compute)
bash scripts/reproduce_all.sh /secure/cohort_manifest.csv

# Paired single-seed DeLong and descriptive risk–coverage/decision-curve CSVs
python scripts/analyze_predictions.py --predictions outputs/cbis_all/protocol_A_predictions.csv --out outputs/cbis_all/posthoc
```

AUC DeLong comparisons require independent patient observations; the provided script skips patients with duplicated views, rather than assigning false independence. The five-seed paired test remains exploratory when the test patients are reused.

### Other analysis scripts

```bash
# Example Grad-CAM with optional expert masks in an authorized manifest
python scripts/gradcam_examples.py --source-run outputs/cbis/cbis/proposed/seed_11 --manifest /secure/test_only.csv --cohort cbis --out outputs/gradcam

# Cross-cohort evaluation uses SOURCE model and SOURCE temperature; target must be test-only
python scripts/cross_cohort.py --source-run outputs/cbis/cbis/proposed/seed_11 --target-manifest /secure/target_test_only.csv --target-cohort private --out outputs/transfer

# Actual nested training-fraction learning curve (computationally expensive)
python scripts/learning_curve.py --manifest /secure/cohort.csv --cohort cbis --out outputs/learning_curve
```

These scripts require real data and trained weights. None generates the manuscript's published Grad-CAM maps, transfer AUCs or learning curves without running the corresponding experiments.
